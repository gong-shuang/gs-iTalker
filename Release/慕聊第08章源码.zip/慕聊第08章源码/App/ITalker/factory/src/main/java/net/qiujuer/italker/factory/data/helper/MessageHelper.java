package net.qiujuer.italker.factory.data.helper;

import net.qiujuer.italker.factory.model.db.Message;

/**
 * 消息工具类
 *
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class MessageHelper {
    // 从本地找消息
    public static Message findFromLocal(String id) {
        // TODO 从本地找消息
        return null;
    }
}
