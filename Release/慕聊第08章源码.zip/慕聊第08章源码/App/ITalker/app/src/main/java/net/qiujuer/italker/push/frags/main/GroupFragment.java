package net.qiujuer.italker.push.frags.main;


import net.qiujuer.italker.common.app.Fragment;
import net.qiujuer.italker.push.R;

public class GroupFragment extends Fragment {

    public GroupFragment() {
        // Required empty public constructor
    }

    @Override
    protected int getContentLayoutId() {
        return R.layout.fragment_group;
    }

}
