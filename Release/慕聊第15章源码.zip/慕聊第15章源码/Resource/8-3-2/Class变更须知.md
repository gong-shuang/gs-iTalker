### Class变更须知：


**手机端项目**

都是factory/data目录下文件变更，直接copy对应文件夹覆盖即可。

net.qiujuer.italker.factory.data.group:

* GroupDispatcher.java

net.qiujuer.italker.factory.data.message:

* MessageDispatcher.java
